package arcuit.kpiweb.model.chart;

public class ChartDatasetBean {
    private String[] labels;
    private long[] data;
}
